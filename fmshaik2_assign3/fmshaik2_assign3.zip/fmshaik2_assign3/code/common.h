#ifndef __COMMON_H__
#define __COMMON_H__

void pre_processing(char*,char*);
void create_trees(int);
void calculate_label(void);
void post_processing(void);

#endif
